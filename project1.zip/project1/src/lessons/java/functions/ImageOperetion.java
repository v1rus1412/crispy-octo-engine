package lessons.java.functions;

public interface ImageOperetion {
    float[] execute(float[] rgb);

}
